This is the first version of ChatProgram.
The communication is working just need to make some minor fixes in the Client's MessageUI
to enable the client of saving and showing contacts. 